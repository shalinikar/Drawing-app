### Create a Drawing App with HTML5 Canvas and JavaScript

Article located at: http://wmalone.com/draw

![My image](http://www.williammalone.com/articles/create-html5-canvas-javascript-drawing-app/images/html5-drawing-tool-example.png)